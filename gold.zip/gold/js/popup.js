Vue.config.debug = true;
window.onload = function() {
  new Vue({
    el: '#app',
    data: {
      toolMode: 'MD5',
      md5: {
        text: '',
        encode: function() {
          
          this.text = $.md5(this.text)
        }
      },
      base64: {
        text: '',
        encode: function() {
          this.text = btoa(this.text);
        },
        decode: function() {
          this.text = atob(this.text);
        }
      },
      gold:{
        showprice:function(){
            $.ajax({
                async: false,
                  url: 'http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=0000011,3990012,3990062&sty=DFPIU&st=z&sr=&p=&ps=&cb=&token=44c9d251add88e27b65ed86506f6e5da&0.811615590220259',
                  type: 'POST'
              }).then(function(response){
                  response = response.replace(/\(|\)/g,'');
                  var j = JSON.parse(response);
                  var priceHtml  = '深证　指数:　　　　' + j[1].split(',')[5] + "　　　　　　　　　　　　";
                      priceHtml += '上证　指数:　　　　' + j[0].split(',')[5] + '　　　　　　　　　　　　';
					  priceHtml += '创业板指数:　　　　' + j[2].split(',')[5] + '　　　　　　　　　　　　';
                  chrome.notifications.create(null, {
                    type: 'basic',
                    iconUrl: 'img/icon.png',
                    title: '大盘指数',
                    message: priceHtml
                  });
              },function(){
                 chrome.notifications.create(null, {
                    type: 'basic',
                    iconUrl: 'img/icon.png',
                    title: '获取失败',
                    message: '获取失败'
                  });
              });
        }
      }
    }
  });
};
