//-------------------- 右键菜单演示 ------------------------//
chrome.contextMenus.create({
	title: "显示黄金价格",
	onclick: function(){
		   $.ajax({
		   		async: false,
		        url: 'https://mybank.icbc.com.cn/servlet/AsynGetDataServlet?Area_code=0200&trademode=1&proIdsIn=130060000043&tranCode=A00500',
		        type: 'POST',
		        dataType: 'json'
		    }).then(function(response){
			   var buyprice = 269.56;
			   var q = 621;
			   var winloss = (response.market[0].buyprice - buyprice) * q;
			   var  priceHtml = '';
			   // var  priceHtml  = '亏　　　损:　　　　' + winloss.toFixed(2) + '　　　　　　　　　　　　';
			        priceHtml += '卖出　价格:　　　　' + response.market[0].buyprice + "　　　　　　　　　　　　";
		            //priceHtml += '买入　价格:　　　　' + response.market[0].sellprice + '　　　　　　　　　　　　';
		         	// priceHtml += '最低中间价:　　　　' + response.market[0].lowmiddleprice + '　　　　　　　　　　　　';
		         	// priceHtml += '最高中间价:　　　　' + response.market[0].topmiddleprice + '　　　　　　　　　　　　';
		         	priceHtml += '涨　　　幅:　　　　' + response.market[0].openprice_dr + '　　　　　　　　　　　　';
				if(winloss <0 ){
					var icon_url = 'img/sad.png';
				}else{
					var icon_url = 'img/smile.png';
				}
				
				var json_str = {
					type: 'basic',
					iconUrl: icon_url,
					title: '黄金价格',
					message: priceHtml
				}
				
		        chrome.notifications.create(null, json_str);
		    },function(){
		       chrome.notifications.create(null, {
					type: 'basic',
					iconUrl: 'img/sad.png',
					title: '获取失败',
					message: '获取失败'
				});
		    });
			
			// $.ajax({
   //              async: false,
   //                url: 'http://nufm.dfcfw.com/EM_Finance2014NumericApplication/JS.aspx?type=CT&cmd=0000011,3990012,3990062&sty=DFPIU&st=z&sr=&p=&ps=&cb=&token=44c9d251add88e27b65ed86506f6e5da&0.811615590220259',
   //                type: 'POST'
   //            }).then(function(response){
   //                response = response.replace(/\(|\)/g,'');
   //                var j = JSON.parse(response);
   //                var priceHtml  = '深证　指数:　　　　' + j[1].split(',')[5] + "　　　　　　　　　　　　";
   //                    priceHtml += '上证　指数:　　　　' + j[0].split(',')[5] + '　　　　　　　　　　　　';
			// 		  priceHtml += '创业板指数:　　　　' + j[2].split(',')[5] + '　　　　　　　　　　　　';
   //                chrome.notifications.create(null, {
   //                  type: 'basic',
   //                  iconUrl: 'img/icon.png',
   //                  title: '大盘指数',
   //                  message: priceHtml
   //                });
   //            },function(){
   //               chrome.notifications.create(null, {
   //                  type: 'basic',
   //                  iconUrl: 'img/icon.png',
   //                  title: '获取失败',
   //                  message: '获取失败'
   //                });
   //            });
			
	}
})


